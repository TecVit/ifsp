def principal():
    cidades = ["São Paulo", "Belo Horizonte", "Tokio"]
    idades = [5, 24, 81, 123, 321, 7]
    flores = ["margarida", "rosa", "tulipa", "cravo"]
    alunos = ["Maria", "22", "Rua Japão, 111", "Cadeira", "Programação", "7.5", "Ana", "6.6"]
    notas = [3.4, 10.0, 9.7, 5.0, 5.9]
    carros = ["Toyota", "Fusca", "Gol"]
    horas = [1, 2, 6, 9, 10]

principal()