def multiplicar(x, y):
  return x * y

x = int(input())
y = int(input())

multiplicacao = multiplicar(x, y)
print(f"A multiplicação é: {multiplicacao}")