s, c = 0, 0

while c < 5:
  n = int(input('Digite um número: '))
  s += n
  c += 1

print('A soma é:', s)