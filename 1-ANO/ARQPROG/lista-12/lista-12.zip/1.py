c = 0
while c < 20:
  print("Algoritimo")
  c += 1