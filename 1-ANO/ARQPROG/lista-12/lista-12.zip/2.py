c = 0
while c < 80:
  print("Y")
  c += 1