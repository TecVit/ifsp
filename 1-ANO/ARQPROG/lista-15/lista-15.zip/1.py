def main():
  n = 100
  soma = 0

  for i in range(1, n + 1):
    soma += i
  
  print(soma)

  return 0

main()