def main():
  n = 500

  for i in range(1, n):
    if i % 5 == 0:
      print(i, end=" ")
  
  print()

  return 0

main()