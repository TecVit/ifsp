def main():
  n = 50

  for i in range(1, n + 1, 2):
    print(i, end=" ")
  
  print()

  return 0

main()