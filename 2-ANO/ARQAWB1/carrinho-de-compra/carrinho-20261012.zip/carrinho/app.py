from flask import Flask, render_template, session, redirect

app = Flask(__name__)
app.secret_key="Carrinho_de_Compra"

lista_produtos = [
    "Detergente", "Macarrão", "Vassoura", "Refrigerante",
]

@app.route('/')
def home():
    return render_template("home.html", lista_produtos=lista_produtos)

@app.route('/ver_carrinho')
def ver_carrinho():
    return render_template('ver_carrinho.html')

@app.route('/adicionar/<nome_produto>')
def adicionar_carrinho(nome_produto):

    if "carrinho" not in session:
        session['carrinho'] = []

    lista_aux = session['carrinho']
    lista_aux.append(nome_produto)
    session['carrinho'] = lista_aux

    return redirect('/')

@app.route('/esvaziar')
def esvaziar_carrinho():

    if "carrinho" in session:
        session.pop('carrinho')
        
    return redirect('/')