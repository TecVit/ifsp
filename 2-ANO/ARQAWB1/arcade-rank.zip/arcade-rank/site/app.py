from flask import Flask, render_template, flash, redirect, url_for, request, session

app = Flask(__name__)
app.secret_key = "sim"

user_admin = "admin"
password_admin = "admin"

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/login")
def login():
    return render_template("login.html")

@app.route("/auth", methods=["POST"])
def auth():
    user = request.form.get("user")
    password = request.form.get("password")

    # Se usuario certo
    if user == user_admin and password == password_admin:
        session["user"] = user
        session["logged"] = True

        return redirect("/dashboard")

    return redirect("/login")

# Dashboard

@app.route("/dashboard")
def dashboard():
    logged = session.get("logged")

    if not logged:
        return redirect("/login")

    # Usuario logado
    
    return render_template("dashboard.html")

@app.route("/players")
def players():
    logged = session.get("logged")

    if not logged:
        return redirect("/login")
    
    return render_template("players.html")

@app.route("/add-point")
def addPoint():
    logged = session.get("logged")

    if not logged:
        return redirect("/login")
    
    return render_template("addPoint.html")