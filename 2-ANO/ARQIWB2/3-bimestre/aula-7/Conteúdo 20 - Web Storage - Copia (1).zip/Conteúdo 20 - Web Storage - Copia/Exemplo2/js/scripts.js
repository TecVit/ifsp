window.onload = principal;

function salvarDados() {
    let pessoa = {
        nome: document.getElementById('nome').value,
        idade: document.getElementById('idade').value
    };

    let pessoas = JSON.parse(localStorage.getItem('pessoas')) || [];
    pessoas.push(pessoa);
    localStorage.setItem('pessoas', JSON.stringify(pessoas));

    listarDados();
}

function listarDados() {
    let pessoas = JSON.parse(localStorage.getItem('pessoas'));
    const lista = document.getElementById('lista');
    lista.innerHTML = ''; // remover todas os itens da lista
    for(let pessoa of pessoas){
        const li = document.createElement('li');
        li.textContent = "Nome: " + pessoa.nome + " - idade: " + pessoa.idade;
        lista.appendChild(li);
    }
}

function limparDados(){
    localStorage.removeItem('pessoas');
    listarDados();
}

function principal() {
    document.getElementById('btnSalvar').onclick = salvarDados;
    document.getElementById('btnRemover').onclick = limparDados;
    listarDados();
}
