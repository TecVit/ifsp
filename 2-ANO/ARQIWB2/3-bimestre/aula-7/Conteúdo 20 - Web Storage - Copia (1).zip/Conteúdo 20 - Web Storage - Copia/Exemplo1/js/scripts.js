window.onload = principal;

function principal() {
    let contador = localStorage.getItem('contador') || 0;
    document.getElementById('contador').textContent = contador;
    document.getElementById('btnIncrementar').addEventListener('click', function () {
        contador++;
        localStorage.setItem('contador', contador);
        document.getElementById('contador').textContent = contador;
    });
}