window.onload = principal;

function principal(){
    // Verificar se usuário não concordou com os termos-> exiba ou não a DIV
    let aceiteUsuario = getCookie("aceiteUsuario");

    if (aceiteUsuario != "true") {
        document.querySelector(".box").style.display = 'flex';
    } else {
        document.querySelector(".box").style.display = 'none';
    }

    let botaoAceitar = document.querySelector("#aceitar");
    botaoAceitar.addEventListener('click', aceitarTermos);

    let botaoRejeitar = document.querySelector("#rejeitar");
    botaoRejeitar.addEventListener('click', rejeitarTermos);
}

function aceitarTermos() {
    document.cookie = "aceiteUsuario=true;";
    document.querySelector(".box").style.display = 'none';    
}

function rejeitarTermos() {
    document.querySelector(".box").style.display = 'none';    
}

function getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}


