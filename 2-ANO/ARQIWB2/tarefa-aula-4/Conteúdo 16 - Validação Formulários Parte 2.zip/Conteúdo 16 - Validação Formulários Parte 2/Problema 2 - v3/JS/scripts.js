window.onload = iniciarPagina;

function iniciarPagina() {
  document.getElementById("f1").noValidate = true;
  document.getElementById("f1").onsubmit = function () {
    return validarDados(this);
  }
}

function validarDados(f) {
  let elementos = f.elements;

  // limpar mensagens customizadas
  for (let i = 0; i < elementos.length; i++) {
    elementos[i].setCustomValidity("");
  }

  validarCamposComuns(f); 

  return f.reportValidity();

}

function validarCamposComuns(f) {
  let campoNome = f.elements["nome"];
  let campoSobrenome = f.elements["sobrenome"];

  if (!campoNome.validity.valid) {
    campoNome.setCustomValidity("Nome com menos de 3 caracteres");
  }
  if (!campoSobrenome.validity.valid) {
    campoSobrenome.setCustomValidity("Sobrenome com menos de 3 caracteres");
  }
  if (campoNome.value == campoSobrenome.value) {
    let erro = campoSobrenome.validationMessage;
    let novoErro = "Nome e sobrenome iguais";
    campoSobrenome.setCustomValidity(erro.length > 0 ? erro + "\n" + novoErro : novoErro);
  }
}
