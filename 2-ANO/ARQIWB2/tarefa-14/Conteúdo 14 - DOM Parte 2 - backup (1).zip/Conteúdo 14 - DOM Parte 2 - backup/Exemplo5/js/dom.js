let titulo = document.querySelector('#titulo-principal');
titulo.style.color = 'red';
titulo.style.backgroundColor = 'yellow';
titulo.style.width = '400px';
