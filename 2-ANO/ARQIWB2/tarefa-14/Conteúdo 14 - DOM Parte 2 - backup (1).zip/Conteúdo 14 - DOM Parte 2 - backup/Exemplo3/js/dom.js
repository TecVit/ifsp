let novoElemento = document.createElement("p");
let texto = document.createTextNode("Algum texto");

novoElemento.appendChild(texto);

let titulo = document.querySelector('#titulo-principal');
let paiTitulo = titulo.parentNode;

paiTitulo.replaceChild(novoElemento, titulo);