let itens = document.querySelectorAll('.itens');

console.log(itens);

let todosPs = document.querySelectorAll('p');

console.log(todosPs);