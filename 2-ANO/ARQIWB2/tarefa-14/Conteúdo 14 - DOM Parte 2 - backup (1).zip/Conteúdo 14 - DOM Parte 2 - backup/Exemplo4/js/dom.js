let a = document.querySelector("footer a");

console.log(a.getAttribute('href'));

let link = 'https://www.arq.ifsp.edu.br/';

a.setAttribute('href', link);

console.log(a.getAttribute('href'));