window.onload = iniciarPagina;

function iniciarPagina() {
   let formulario = document.getElementById("form1");
   formulario.onsubmit = validarDados; 
}

function validarDados() {
   let nome = document.getElementById("nome").value;
   let sobrenome = document.getElementById("sobrenome").value;

   if (nome == sobrenome) {
    alert("Erro: Nome e sobrenome são iguais.\nInforme valores diferentes.");
    return false;
  }
  return true; //instrução default
}