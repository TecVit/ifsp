window.onload = principal;

function principal() {
    let btnSalvar = document.getElementById('btnSalvar');
    btnSalvar.onclick = salvarDados;

    let btnRemover = document.getElementById('btnRemover');
    btnRemover.onclick = removerDados;
}

function salvarDados() {
    let pessoa = {
        nome: document.getElementById('nome').value,
        idade: document.getElementById('idade').value
    };

    let pessoas = JSON.parse(localStorage.getItem('pessoas')) || [];
    pessoas.push(pessoa);

    localStorage.setItem('pessoas', JSON.stringify(pessoas));

    listarDados();
}

function listarDados() {
    let pessoas = JSON.parse(localStorage.getItem('pessoas'));
    let lista = document.getElementById('lista');

    lista.innerHTML = '';

    if (pessoas != null) {
        for (let pessoa of pessoas) {
            let li = document.createElement('li');
            li.innerHTML = 'Nome: ' + pessoa.nome + ' - idade: ' + pessoa.idade;
            lista.appendChild(li);
        }
    }
}

function removerDados() {
    localStorage.removeItem('pessoas');
    listarDados();
}